import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: Home()));
}

class Home extends StatefulWidget {
  const Home({
    Key? key,
  }) : super(key: key);
  @override
  State<StatefulWidget> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 9, 0, 92),
        title: const Text("Cloud"),
      ),
      body: ListView(
        children: [
          Column(
            children: [
              Container(
                child: ListTile(
                  title: Text("Santa Catarina"),
                ),
                margin: const EdgeInsets.only(
                  left: 10.0,
                  right: 20.0,
                  top: 10.0,
                ),
              ),
              Container(
                  margin: const EdgeInsets.only(
                    left: 20.0,
                    right: 20.0,
                    top: 10.0,
                  ),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xe9e9e9e9),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xe9e9e9e9),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Concórdia, SC"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Arabutã, SC"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Chapecó, SC"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Florianópolis, SC"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Ipumirim, SC"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(title: Text("Irani, SC"))),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(title: Text("Itá, SC"))),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(title: Text("Jaborá, SC"))),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(title: Text("Joaçaba, SC"))),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(title: Text("Peritiba, SC"))),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(title: Text("Piratuba, SC"))),
              Container(
                  margin: const EdgeInsets.only(
                      left: 20.0, right: 20.0, top: 20.0, bottom: 20),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ScreenCharacters(),
                            ));
                      },
                      title: Text("Seara, SC"))),
              const Divider(
                thickness: 0.75,
                color: Colors.black,
                indent: 20.0,
                endIndent: 20.0,
              ),
              Container(
                child: ListTile(
                  title: Text("Brasil"),
                ),
                margin: const EdgeInsets.only(
                  left: 10.0,
                  right: 20.0,
                  top: 10.0,
                ),
              ),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(title: Text("Curitiba, PR"))),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Porto Alegre, RS"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Recife, PE"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Rio de Janeiro, RJ"),
                  )),
              Container(
                  margin: const EdgeInsets.only(
                      left: 20.0, right: 20.0, top: 20.0, bottom: 20),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("São Paulo, SP"),
                  )),
              const Divider(
                thickness: 0.75,
                color: Colors.black,
                indent: 20.0,
                endIndent: 20.0,
              ),
              Container(
                child: ListTile(
                  title: Text("Mundo"),
                ),
                margin: const EdgeInsets.only(
                  left: 10.0,
                  right: 20.0,
                  top: 10.0,
                ),
              ),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Londres, UK"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Madrid, ES"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Nova York, EUA"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Paris, FRA"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Roma, ITA"),
                  )),
              Container(
                  margin:
                      const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Seul, KOR"),
                  )),
              Container(
                  margin: const EdgeInsets.only(
                      left: 20.0, right: 20.0, top: 20.0, bottom: 20.0),
                  padding: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color(0xf2f2f2f2),
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color(0xf2f2f2f2),
                    // backgroundBlendMode:
                  ),
                  child: ListTile(
                    title: Text("Tóquio, JAP"),
                  )),
            ],
          )
        ],
      ),
    );
  }
}
