import 'dart:math';
import 'package:flutter/material.dart';

import 'detalhescidades.dart';

class Cidade {
  int lat;
  int long;
  String nome;
  Current current;

  Cidade(
      {required this.lat,
      required this.long,
      required this.nome,
      required this.current});
}
