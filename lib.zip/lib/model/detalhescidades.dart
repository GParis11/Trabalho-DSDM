class Weather {
  int id;
  String? main;
  String? description;
  String? icon;

  Weather({required this.id, this.main, this.description, this.icon});
}

class Current {
  int? temp;
  int? feels_like;
  int? max;
  int? min;
  Weather? weather;

  Current({this.temp, this.feels_like, this.max, this.min, this.weather});
}

class Hourly {
  int? humidity;
}
